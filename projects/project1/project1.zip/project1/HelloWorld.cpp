/* 
 * Project 1: Hello World
 * Engs 65 
 * Author : Brett Nicholas
 */
#include <iostream>
using namespace std;

int main()
{
	  std::cout << "Hello World!\n";
	  return 0; 
}

