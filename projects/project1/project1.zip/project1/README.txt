This program was written in C++ by Brett Nicholas for ENGS 65 project #1. 
It was written on the command line using vim, and compiled using g++ as seen below

gcc -o HelloWorld HelloWorld.cpp

